# SADEE SOLUTIONS STORE FIXED
Includes a separate Supabase admin panel at `/admin/`, product CRUD, image upload, orders view, eZ Cash payment instructions, WhatsApp ordering and the official WhatsApp channel link.

Admin URL:
https://sadee999.github.io/SADEE_SOLUTIONS_STORE/admin/

Supabase Auth requirement:
1. Create the admin account in Authentication > Users.
2. Put the same email in public.admin_users.
3. The password is the Supabase Auth password; it is not stored in the website code.
