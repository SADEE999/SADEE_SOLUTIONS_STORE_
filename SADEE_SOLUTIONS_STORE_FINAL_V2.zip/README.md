# SADEE SOLUTIONS — Official Store

Customer storefront + separate private admin page.

## Customer website
`https://sadee999.github.io/SADEE-SOLUTIONS-STORE/`

The public store contains no Admin/Dashboard button.

Features:
- Live Supabase catalog with local fallbacks
- Search and category filters
- Saved/favourite products stored on the device
- Product sharing
- Product details and feature lists
- WhatsApp ordering to +94 76 847 2404
- Supabase order recording
- Mobile-first responsive design
- Showcase video
- FAQ and ordering guide

## Private admin
Use the root file below rather than an `/admin/` directory:

`https://sadee999.github.io/SADEE-SOLUTIONS-STORE/admin.html`

This avoids the directory-route 404 problem on GitHub Pages.

Admin features:
- Supabase Auth login
- Admin verification with `is_admin()` RPC
- Product add/edit/delete
- Price and price-note editing
- Description/features editing
- Product image upload
- Featured / active controls
- Duplicate products
- Product search and filters
- Order search and status management
- Revenue/order statistics
- CSV order export
- Database refresh

## Deployment
GitHub Pages source must be **GitHub Actions**. The included workflow deploys the repository root directly; it does not extract a ZIP and does not depend on an `/admin/` folder.

## Supabase
Run `supabase.sql` in the Supabase SQL Editor. Keep only a browser-safe publishable/anon key in `config.js`; never put a service-role key in browser code.
