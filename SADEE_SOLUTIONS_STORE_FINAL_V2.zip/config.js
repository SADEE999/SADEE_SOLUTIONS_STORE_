// Browser-safe Supabase configuration.
// NEVER place a service_role/secret key in this file.
window.SUPABASE_URL = "https://cojrwjytgzxgjyzhnays.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_ve_c8o_QxnzRtxpAhGjhEg_ZUkOIDo-";
window.WHATSAPP_NUMBER = "94768472404";
