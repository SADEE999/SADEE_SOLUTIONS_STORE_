const sb=(window.SUPABASE_URL&&window.SUPABASE_ANON_KEY&&!window.SUPABASE_URL.includes('YOUR_'))?window.supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY):null;
const FALLBACK=[
{id:'local-1',name:'SADEE SOLUTIONS — App & Website Package',category:'Development',price:1000,price_note:'Inbox for final price',image_url:'assets/sadee-solutions.jpg',description:'Custom app and website development package for digital businesses.',features:['Custom mobile applications','Custom websites','Cloud solutions','API integration','Digital innovation'],featured:true,active:true},
{id:'local-2',name:'SADEE SENSITIVE PRO',category:'Gaming',price:1000,price_note:'Lifetime',image_url:'assets/sadee-sensitive-pro.png',description:'Free Fire sensitivity tool for creating device-based sensitivity profiles.',features:['Free Fire sensitivity profiles','Device-based setup','Custom presets','Lifetime access'],featured:true,active:true},
{id:'local-3',name:'SADEE X DIMA OPTIMIZER',category:'Gaming',price:500,price_note:'7 day key • 1 month Rs.1000 • Lifetime Rs.2200',image_url:'assets/sadee-x-dima-optimizer.png',description:'Optimization system with device information, RAM/storage utilities, game tools and activation-key access.',features:['7 day key — Rs.500','1 month — Rs.1000','Lifetime — Rs.2200','Device information','RAM / storage tools','Game optimization tools'],featured:true,active:true}
];
let products=[...FALLBACK],showSavedOnly=false;
const $=s=>document.querySelector(s),esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const imgFor=p=>(p.image_url||p.image||'').trim()||(String(p.name).includes('SENSITIVE PRO')?'assets/sadee-sensitive-pro.png':String(p.name).includes('OPTIMIZER')?'assets/sadee-x-dima-optimizer.png':'assets/sadee-solutions.jpg');
const money=p=>p.price_note?.toLowerCase().includes('inbox')?`Rs. ${Number(p.price||0).toLocaleString()}+`:`Rs. ${Number(p.price||0).toLocaleString()}`;
const getFav=()=>JSON.parse(localStorage.getItem('sadee_favourites')||'[]'),setFav=a=>localStorage.setItem('sadee_favourites',JSON.stringify(a));
const getRecent=()=>JSON.parse(localStorage.getItem('sadee_recent')||'[]'),setRecent=a=>localStorage.setItem('sadee_recent',JSON.stringify(a.slice(0,8)));
const isFav=id=>getFav().map(String).includes(String(id));
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(window.__t);window.__t=setTimeout(()=>t.classList.remove('show'),2600)};
function updateFavCount(){const n=getFav().length;$('#favCount').textContent=n;$('#savedCount').textContent=n}
function syncCounts(n){$('#heroProductCount').textContent=`${n}+`;$('#catalogCount').textContent=`${n}+`;updateFavCount()}
function buildChips(){const cats=[...new Set(products.filter(p=>p.active!==false).map(p=>p.category).filter(Boolean))].sort();$('#categoryChips').innerHTML=`<button class="chip ${!$('#category').value?'active':''}" data-cat="">ALL</button>`+cats.map(c=>`<button class="chip ${$('#category').value===c?'active':''}" data-cat="${esc(c)}">${esc(c).toUpperCase()}</button>`).join('')}
function render(){
 const q=$('#search').value.toLowerCase().trim(),cat=$('#category').value,fav=getFav().map(String);
 const list=products.filter(p=>p.active!==false&&(!q||`${p.name} ${p.description||''} ${p.category||''} ${(p.features||[]).join(' ')}`.toLowerCase().includes(q))&&(!cat||p.category===cat)&&(!showSavedOnly||fav.includes(String(p.id))));
 $('#status').textContent=showSavedOnly?`${list.length} saved product${list.length===1?'':'s'}`:`${list.length} product${list.length===1?'':'s'} available`;
 const html=list.map(p=>`<article class="card"><div class="card-img"><img loading="lazy" src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'">${p.featured?'<span class="badge">FEATURED</span>':''}<button class="fav-btn ${isFav(p.id)?'saved':''}" data-fav="${esc(p.id)}" aria-label="Save product">${isFav(p.id)?'♥':'♡'}</button><span class="card-index">${String(p.id).slice(0,4).toUpperCase()}</span></div><div class="card-body"><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h3>${esc(p.name)}</h3><p class="desc">${esc(p.description||'Premium digital product from SADEE SOLUTIONS.')}</p><div class="price-row"><div class="price">${money(p)}</div><span class="available">● AVAILABLE</span></div><div class="card-actions"><button class="btn primary view-btn" data-id="${esc(p.id)}">VIEW & BUY <span>↗</span></button><button class="square-btn share-btn" data-id="${esc(p.id)}" aria-label="Share product">↗</button></div></div></article>`).join('');
 $('#products').innerHTML=list.length?html:"<div class='empty'><b>NO PRODUCTS FOUND</b><span>Try another search, category or saved filter.</span></div>";buildChips();updateFavCount();
}
function toggleFav(id){let a=getFav().map(String),s=String(id);a=a.includes(s)?a.filter(x=>x!==s):[...a,s];setFav(a);toast(a.includes(s)?'Product saved':'Product removed from saved');render()}
function openDetail(id){
 const p=products.find(x=>String(x.id)===String(id));if(!p)return;let r=getRecent().map(String).filter(x=>x!==String(id));r.unshift(String(id));setRecent(r);
 $('#detail').innerHTML=`<div class="detail-grid"><div><div class="detail-image"><img src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'"></div><div class="detail-tools"><button class="mini-btn save-detail ${isFav(p.id)?'saved':''}" id="saveDetail">${isFav(p.id)?'♥ SAVED':'♡ SAVE PRODUCT'}</button><button class="mini-btn" id="shareDetail">SHARE ↗</button></div></div><div class="detail-copy"><span class="status-pill">● ${p.active!==false?'AVAILABLE':'UNAVAILABLE'}</span><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h2>${esc(p.name)}</h2><div class="detail-price">${money(p)} <small>${esc(p.price_note||'')}</small></div><p>${esc(p.description||'')}</p><ul class="feature-list">${(p.features||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><div class="order-fields"><input id="customerName" placeholder="Your name (optional)" autocomplete="name"><input id="customerPhone" placeholder="Phone (optional)" inputmode="tel" autocomplete="tel"></div><button class="btn primary buy-btn" id="buyBtn">BUY NOW — WHATSAPP ↗</button><small class="order-note">Order details are recorded when Supabase is available, then WhatsApp opens.</small></div></div>`;
 $('#drawer').classList.add('show');$('#drawer').setAttribute('aria-hidden','false');document.body.classList.add('modal-open');
 $('#buyBtn').onclick=()=>placeOrder(p);$('#shareDetail').onclick=()=>shareProduct(p);$('#saveDetail').onclick=()=>toggleFav(p.id);
}
async function shareProduct(p){const text=`${p.name} — ${money(p)} | SADEE SOLUTIONS`;try{if(navigator.share)await navigator.share({title:p.name,text,url:location.href.split('#')[0]});else{await navigator.clipboard.writeText(`${text}\n${location.href}`);toast('Product link copied')}}catch(e){}}
async function placeOrder(p){
 const name=$('#customerName')?.value.trim()||'',phone=$('#customerPhone')?.value.trim()||'',btn=$('#buyBtn');btn.disabled=true;btn.textContent='PREPARING ORDER…';
 if(sb){const {error}=await sb.from('orders').insert({product_id:p.id,product_name:p.name,price:Number(p.price||0),customer_name:name,customer_phone:phone,source:'whatsapp',status:'new'});if(error)console.warn('Order record failed:',error.message)}
 const msg=`Hello SADEE SOLUTIONS 👋\n\nI want to order:\n*${p.name}*\nPrice: ${money(p)}\n${name?`Name: ${name}\n`:''}${phone?`Phone: ${phone}\n`:''}\nPlease send me the payment/order details.`;
 window.open(`https://wa.me/${window.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,'_blank','noopener');btn.disabled=false;btn.textContent='ORDER SENT — WHATSAPP ↗';toast('WhatsApp order prepared');
}
async function loadProducts(){
 if(!sb){syncCounts(products.length);render();return}
 const {data,error}=await sb.from('products').select('*').order('created_at',{ascending:false});
 if(!error&&data?.length){products=data.map(p=>({...p,image_url:imgFor(p)}));const cats=[...new Set(data.map(x=>x.category).filter(Boolean))].sort();$('#category').innerHTML='<option value="">All categories</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');syncCounts(data.filter(p=>p.active!==false).length);$('#storeIntro').textContent='Live catalog • synced from Supabase';}
 else {syncCounts(products.length);if(error)console.warn('Store database unavailable:',error.message)}render();
}
$('#products').addEventListener('click',e=>{const view=e.target.closest('.view-btn'),share=e.target.closest('.share-btn'),fav=e.target.closest('.fav-btn');if(view)openDetail(view.dataset.id);if(share)shareProduct(products.find(p=>String(p.id)===String(share.dataset.id)));if(fav)toggleFav(fav.dataset.fav)});
$('#categoryChips').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;$('#category').value=b.dataset.cat||'';showSavedOnly=false;$('#savedOnly').classList.remove('active');render()});
$('#search').addEventListener('input',render);$('#category').addEventListener('change',render);
$('#clearSearch').onclick=()=>{$('#search').value='';$('#category').value='';showSavedOnly=false;$('#savedOnly').classList.remove('active');render()};
$('#savedOnly').onclick=()=>{showSavedOnly=!showSavedOnly;$('#savedOnly').classList.toggle('active',showSavedOnly);render()};
$('#closeDrawer').onclick=()=>{$('#drawer').classList.remove('show');$('#drawer').setAttribute('aria-hidden','true');document.body.classList.remove('modal-open')};$('#drawer').addEventListener('click',e=>{if(e.target.id==='drawer')$('#closeDrawer').click()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#drawer').classList.contains('show'))$('#closeDrawer').click()});
const menuBtn=$('#menuBtn'),nav=$('#mainNav');menuBtn.addEventListener('click',()=>{const open=document.querySelector('.topbar').classList.toggle('nav-open');menuBtn.setAttribute('aria-expanded',String(open))});nav.addEventListener('click',()=>{document.querySelector('.topbar').classList.remove('nav-open');menuBtn.setAttribute('aria-expanded','false')});
loadProducts();
