-- ============================================================
-- SADEE SOLUTIONS STORE - SUPABASE SETUP / UPGRADE
-- Safe to run on the existing project.
-- ============================================================

create extension if not exists pgcrypto;

-- Existing tables are preserved. Missing columns are added only if needed.
create table if not exists public.admin_users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  created_at timestamptz default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text default 'Digital Product',
  price numeric not null default 0,
  price_note text default '',
  description text default '',
  features jsonb default '[]'::jsonb,
  image_url text default '',
  featured boolean default false,
  active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  price numeric default 0,
  customer_name text default '',
  customer_phone text default '',
  source text default 'whatsapp',
  status text default 'new',
  created_at timestamptz default now()
);

alter table public.products add column if not exists updated_at timestamptz default now();
alter table public.orders add column if not exists source text default 'whatsapp';
alter table public.orders add column if not exists status text default 'new';

-- Admin check: SECURITY DEFINER avoids the admin_users RLS recursion problem.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_users au
    where lower(au.email) = lower(coalesce(auth.jwt()->>'email',''))
  );
$$;

grant usage on schema public to authenticated;
grant execute on function public.is_admin() to authenticated;

grant select on public.products to anon, authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, insert on public.orders to anon, authenticated;
grant update, delete on public.orders to authenticated;
grant select on public.admin_users to authenticated;

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.admin_users enable row level security;

drop policy if exists "public can read active products" on public.products;
create policy "public can read active products"
on public.products for select
using (active = true or public.is_admin());

drop policy if exists "admins can manage products" on public.products;
create policy "admins can manage products"
on public.products for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public can create orders" on public.orders;
create policy "public can create orders"
on public.orders for insert to anon, authenticated
with check (true);

drop policy if exists "admins can read orders" on public.orders;
create policy "admins can read orders"
on public.orders for select to authenticated
using (public.is_admin());

drop policy if exists "admins can manage orders" on public.orders;
create policy "admins can manage orders"
on public.orders for update, delete to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins can read admin users" on public.admin_users;
create policy "admins can read admin users"
on public.admin_users for select to authenticated
using (public.is_admin());

-- Product image storage.
insert into storage.buckets (id,name,public)
values ('product-media','product-media',true)
on conflict (id) do update set public=true;

drop policy if exists "public can view product media" on storage.objects;
create policy "public can view product media"
on storage.objects for select
using (bucket_id='product-media');

drop policy if exists "admins can upload product media" on storage.objects;
create policy "admins can upload product media"
on storage.objects for insert to authenticated
with check (bucket_id='product-media' and public.is_admin());

drop policy if exists "admins can update product media" on storage.objects;
create policy "admins can update product media"
on storage.objects for update to authenticated
using (bucket_id='product-media' and public.is_admin())
with check (bucket_id='product-media' and public.is_admin());

drop policy if exists "admins can delete product media" on storage.objects;
create policy "admins can delete product media"
on storage.objects for delete to authenticated
using (bucket_id='product-media' and public.is_admin());

-- Make sure the real admin email exists. If it already exists, nothing changes.
insert into public.admin_users(email)
values ('sadeeXdima@gmail.com')
on conflict (email) do nothing;

-- Initial products are inserted only if the product name does not exist.
insert into public.products (name,category,price,price_note,description,features,featured,active)
select 'SADEE SOLUTIONS — App & Website Package','Development',1000,'Inbox for final price',
'Custom app and website development package for digital businesses.',
'["Custom mobile applications","Custom websites","Cloud solutions","API integration","Digital innovation"]'::jsonb,true,true
where not exists (select 1 from public.products where name='SADEE SOLUTIONS — App & Website Package');

insert into public.products (name,category,price,price_note,description,features,featured,active)
select 'SADEE SENSITIVE PRO','Gaming',1000,'Lifetime',
'Free Fire sensitivity tool for creating device-based sensitivity profiles.',
'["Free Fire sensitivity profiles","Device-based setup","Custom presets","Lifetime access"]'::jsonb,true,true
where not exists (select 1 from public.products where name='SADEE SENSITIVE PRO');

insert into public.products (name,category,price,price_note,description,features,featured,active)
select 'SADEE X DIMA OPTIMIZER','Gaming',500,'7 day key • 1 month Rs.1000 • Lifetime Rs.2200',
'Optimization system with device information, RAM/storage utilities, game tools and activation-key access.',
'["7 day key — Rs.500","1 month — Rs.1000","Lifetime — Rs.2200","Device information","RAM / storage tools","Game optimization tools"]'::jsonb,true,true
where not exists (select 1 from public.products where name='SADEE X DIMA OPTIMIZER');
