const sb = (window.SUPABASE_URL && window.SUPABASE_ANON_KEY && !window.SUPABASE_URL.includes('YOUR_'))
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY)
  : null;

const FALLBACK = [
  {id:'local-1',name:'SADEE SOLUTIONS — App & Website Package',category:'Development',price:1000,price_note:'Inbox for final price',image_url:'assets/sadee-solutions.jpg',description:'Custom app and website development package for digital businesses.',features:['Custom mobile applications','Custom websites','Cloud solutions','API integration','Digital innovation'],featured:true,active:true},
  {id:'local-2',name:'SADEE SENSITIVE PRO',category:'Gaming',price:1000,price_note:'Lifetime',image_url:'assets/sadee-sensitive-pro.png',description:'Free Fire sensitivity tool for creating device-based sensitivity profiles.',features:['Free Fire sensitivity profiles','Device-based setup','Custom presets','Lifetime access'],featured:true,active:true},
  {id:'local-3',name:'SADEE X DIMA OPTIMIZER',category:'Gaming',price:500,price_note:'7 day key • 1 month Rs.1000 • Lifetime Rs.2200',image_url:'assets/sadee-x-dima-optimizer.png',description:'Optimization system with device information, RAM/storage utilities, game tools and activation-key access.',features:['7 day key — Rs.500','1 month — Rs.1000','Lifetime — Rs.2200','Device information','RAM / storage tools','Game optimization tools'],featured:true,active:true}
];

let products = [...FALLBACK];
const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const imgFor = p => (p.image_url || p.image || '').trim() || (String(p.name).includes('SENSITIVE PRO') ? 'assets/sadee-sensitive-pro.png' : String(p.name).includes('OPTIMIZER') ? 'assets/sadee-x-dima-optimizer.png' : 'assets/sadee-solutions.jpg');
const money = p => p.price_note?.toLowerCase().includes('inbox') ? `Rs. ${Number(p.price||0).toLocaleString()}+` : `Rs. ${Number(p.price||0).toLocaleString()}`;

function render(){
  const q = $('#search').value.toLowerCase().trim();
  const cat = $('#category').value;
  const list = products.filter(p => p.active !== false && (!q || `${p.name} ${p.description||''} ${p.category||''}`.toLowerCase().includes(q)) && (!cat || p.category === cat));
  $('#status').textContent = `${list.length} product${list.length===1?'':'s'} available`;
  $('#products').innerHTML = list.length ? list.map(p => `
    <article class="card" data-id="${esc(p.id)}">
      <div class="card-img"><img loading="lazy" src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'">${p.featured?'<span class="badge">FEATURED</span>':''}<span class="card-index">${String(p.id).slice(0,4).toUpperCase()}</span></div>
      <div class="card-body"><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h3>${esc(p.name)}</h3><p class="desc">${esc(p.description||'Premium digital product from SADEE SOLUTIONS.')}</p><div class="price-row"><div class="price">${money(p)}</div><span class="available">● AVAILABLE</span></div><button class="btn primary view-btn" data-id="${esc(p.id)}">VIEW & BUY <span>↗</span></button></div>
    </article>`).join('') : '<div class="empty"><b>NO PRODUCTS FOUND</b><span>Try another search or category.</span></div>';
}

function openDetail(id){
  const p = products.find(x => String(x.id) === String(id)); if(!p) return;
  $('#detail').innerHTML = `<div class="detail-grid"><div><div class="detail-image"><img src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'"></div></div><div class="detail-copy"><span class="status-pill">● ${p.active!==false?'AVAILABLE':'UNAVAILABLE'}</span><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h2>${esc(p.name)}</h2><div class="detail-price">${money(p)} <small>${esc(p.price_note||'')}</small></div><p>${esc(p.description||'')}</p><ul class="feature-list">${(p.features||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><div class="order-fields"><input id="customerName" placeholder="Your name (optional)" autocomplete="name"><input id="customerPhone" placeholder="Phone (optional)" inputmode="tel" autocomplete="tel"></div><div class="payment-box"><b>PAYMENT</b><span>eZ Cash: <strong>0760625028</strong></span><small>After payment, send your payment proof on WhatsApp.</small></div><button class="btn primary buy-btn" id="buyBtn">BUY NOW — WHATSAPP ↗</button><button class="btn ghost proof-btn" id="proofBtn">SEND PAYMENT PROOF ↗</button><a class="btn ghost" href="https://whatsapp.com/channel/0029VbE4clL9WtC8Acr91m01" target="_blank" rel="noopener">JOIN WHATSAPP CHANNEL ↗</a><small class="order-note">Your order is recorded for SADEE before WhatsApp opens.</small></div></div>`;
  $('#drawer').classList.add('show'); $('#drawer').setAttribute('aria-hidden','false'); document.body.classList.add('modal-open');
  $('#buyBtn').onclick = () => placeOrder(p);
  $('#proofBtn').onclick = () => { const msg=`Hello SADEE SOLUTIONS 👋\n\nPayment proof for:\n*${p.name}*\n\nI have completed the payment to eZ Cash 0760625028. I will send the proof here.`; window.open(`https://wa.me/${window.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,'_blank','noopener'); };
}

async function placeOrder(p){
  const name = $('#customerName')?.value.trim() || '';
  const phone = $('#customerPhone')?.value.trim() || '';
  const btn = $('#buyBtn'); btn.disabled = true; btn.textContent = 'PREPARING ORDER…';
  if(sb){
    const {error} = await sb.from('orders').insert({product_id:p.id,product_name:p.name,price:Number(p.price||0),customer_name:name,customer_phone:phone,source:'whatsapp'});
    if(error) console.warn('Order record failed:', error.message);
  }
  const msg = `Hello SADEE SOLUTIONS 👋\n\nI want to order:\n*${p.name}*\nPrice: ${money(p)}\n${name?`Name: ${name}\n`:''}${phone?`Phone: ${phone}\n`:''}\nPlease send me the payment/order details.`;
  window.open(`https://wa.me/${window.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,'_blank','noopener');
  btn.disabled = false; btn.textContent = 'ORDER SENT — WHATSAPP ↗';
}

async function loadProducts(){
  if(!sb){ render(); return; }
  const {data,error} = await sb.from('products').select('*').order('created_at',{ascending:false});
  if(!error && data?.length){
    products = data.map(p => ({...p,image_url:imgFor(p)}));
    const cats = [...new Set(data.map(x=>x.category).filter(Boolean))].sort();
    $('#category').innerHTML = '<option value="">All categories</option>' + cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
  } else if(error) console.warn('Store database unavailable:',error.message);
  render();
}

$('#products').addEventListener('click', e => { const b=e.target.closest('.view-btn'); if(b) openDetail(b.dataset.id); });
$('#search').addEventListener('input',render); $('#category').addEventListener('change',render);
$('#closeDrawer').onclick=()=>{ $('#drawer').classList.remove('show'); $('#drawer').setAttribute('aria-hidden','true'); document.body.classList.remove('modal-open'); };
$('#drawer').addEventListener('click',e=>{if(e.target.id==='drawer') $('#closeDrawer').click();});

document.addEventListener('keydown',e=>{if(e.key==='Escape' && $('#drawer').classList.contains('show')) $('#closeDrawer').click();});
const menuBtn=$('#menuBtn'), nav=$('#mainNav');
menuBtn.addEventListener('click',()=>{const open=document.querySelector('.topbar').classList.toggle('nav-open');menuBtn.setAttribute('aria-expanded',String(open));});
nav.addEventListener('click',()=>{document.querySelector('.topbar').classList.remove('nav-open');menuBtn.setAttribute('aria-expanded','false');});
loadProducts();
