# SADEE SOLUTIONS STORE — UPGRADED

Official customer store + separate private admin control center.

## Customer site
- Live Supabase product catalog
- Search + category filters
- Product details
- WhatsApp ordering
- Order records in Supabase
- Product sharing
- Mobile responsive UI
- No public Admin/Dashboard button

## Private admin
Open directly at `/admin/`.
It is intentionally not linked from the public store.

Admin features:
- Supabase email/password login
- Product add/edit/delete
- Image upload to Supabase Storage
- Price/price note editing
- Description/features editing
- Active/hidden toggle
- Featured toggle
- Duplicate product
- Order status updates
- Order search/filter
- Revenue/total order statistics
- CSV export

## GitHub Pages
Use ONLY `.github/workflows/pages.yml` for deployment. Delete/disable old `main.yml`, `static.yml`, `deploy.yml` workflows in the repository before using this version, so multiple Pages deployments do not fight each other.

In GitHub: Settings → Pages → Source → GitHub Actions.

## Supabase
Run `supabase.sql` in Supabase SQL Editor. Never put a service_role key in `config.js`.
