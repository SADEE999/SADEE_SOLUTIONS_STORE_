const sb=window.supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY);
const $=id=>document.getElementById(id);
let products=[],orders=[],busy=false;
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const money=v=>`Rs. ${Number(v||0).toLocaleString()}`;
const toast=(msg,good=true)=>{const t=$('toast');t.textContent=msg;t.className=`toast show ${good?'good':'bad'}`;clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.className='toast',3000)};

async function verifyAdmin(){
  const {data,error}=await sb.rpc('is_admin');
  if(error){$('loginMsg').textContent='Admin verification failed: '+error.message;return false;}
  if(data!==true){await sb.auth.signOut();$('loginMsg').textContent='This account is not registered as an admin.';return false;}
  return true;
}

async function start(){
  if(busy)return;busy=true;
  try{
    const {data,error}=await sb.auth.getSession();
    if(error){$('loginMsg').textContent=error.message;return;}
    if(!data.session){$('login').classList.remove('hidden');$('app').classList.add('hidden');return;}
    const ok=await verifyAdmin();
    if(!ok){$('login').classList.remove('hidden');$('app').classList.add('hidden');return;}
    $('adminEmail').textContent=data.session.user.email||'Admin';
    $('login').classList.add('hidden');$('app').classList.remove('hidden');
    await load();
  }finally{busy=false;}
}

$('loginBtn').onclick=async()=>{
  $('loginMsg').textContent='Signing in…';
  const email=$('email').value.trim(),password=$('password').value;
  if(!email||!password){$('loginMsg').textContent='Enter your email and password.';return;}
  const {error}=await sb.auth.signInWithPassword({email,password});
  if(error){$('loginMsg').textContent=error.message;return;}
  await start();
};
$('password').addEventListener('keydown',e=>{if(e.key==='Enter')$('loginBtn').click();});
$('logout').onclick=async()=>{await sb.auth.signOut();location.reload();};

async function load(){
  $('storeStatus').textContent='Syncing…';
  const [pr,or]=await Promise.all([sb.from('products').select('*').order('created_at',{ascending:false}),sb.from('orders').select('*').order('created_at',{ascending:false})]);
  if(pr.error){toast(pr.error.message,false);products=[];}else products=pr.data||[];
  if(or.error){toast(or.error.message,false);orders=[];}else orders=or.data||[];
  $('storeStatus').textContent=pr.error?'Database error':'LIVE / CONNECTED';$('lastSync').textContent=new Date().toLocaleTimeString();
  render();
}

function render(){
  $('count').textContent=products.length;$('activeCount').textContent=products.filter(p=>p.active).length;$('featuredCount').textContent=products.filter(p=>p.featured).length;$('orderCount').textContent=orders.length;
  const q=$('adminSearch').value.toLowerCase().trim(),f=$('adminFilter').value;
  const list=products.filter(p=>(!q||`${p.name} ${p.category||''}`.toLowerCase().includes(q))&&(f==='all'||(f==='active'&&p.active)||(f==='hidden'&&!p.active)||(f==='featured'&&p.featured)));
  $('table').innerHTML=list.length?list.map(p=>`<article class="product-row"><img src="${esc(p.image_url||'../assets/sadee-solutions.jpg')}" onerror="this.src='../assets/sadee-solutions.jpg'" alt=""><div class="product-info"><div class="tags"><span>${esc(p.category||'Digital')}</span>${p.featured?'<span class="red-tag">FEATURED</span>':''}<span class="${p.active?'green-tag':'gray-tag'}">${p.active?'ACTIVE':'HIDDEN'}</span></div><h3>${esc(p.name)}</h3><p>${esc(p.description||'No description')}</p><b>${money(p.price)} <small>${esc(p.price_note||'')}</small></b></div><div class="row-actions"><button onclick="edit('${p.id}')">EDIT</button><button onclick="toggleActive('${p.id}')">${p.active?'HIDE':'SHOW'}</button><button class="danger" onclick="del('${p.id}')">DELETE</button></div></article>`).join(''):'<div class="empty">No products match this filter.</div>';
  $('orders').innerHTML=orders.length?orders.map(o=>`<article class="order-row"><div class="order-icon">◎</div><div><b>${esc(o.product_name)}</b><p>${esc(o.customer_name||'Guest')} · ${esc(o.customer_phone||'No phone')}</p></div><strong>${money(o.price)}</strong><time>${new Date(o.created_at).toLocaleString()}</time></article>`).join(''):'<div class="empty">No order records yet.</div>';
}

function openForm(p=null){
  $('modal').classList.add('show');$('formTitle').textContent=p?'Edit Product':'Add Product';$('formMode').textContent=p?'PRODUCT EDITOR / EDIT':'PRODUCT EDITOR / NEW';$('pid').value=p?.id||'';$('pname').value=p?.name||'';$('pcat').value=p?.category||'';$('pprice').value=p?.price??'';$('pnote').value=p?.price_note||'';$('pdesc').value=p?.description||'';$('pfeatures').value=(Array.isArray(p?.features)?p.features:[]).join('\n');$('pimageurl').value=p?.image_url||'';$('pfeatured').checked=!!p?.featured;$('pactive').checked=p?p.active!==false:true;$('pimage').value='';$('preview').src=p?.image_url||'../assets/sadee-solutions.jpg';$('saveMsg').textContent='';
}
window.edit=id=>openForm(products.find(p=>String(p.id)===String(id)));
window.toggleActive=async id=>{const p=products.find(x=>String(x.id)===String(id));if(!p)return;const {error}=await sb.from('products').update({active:!p.active}).eq('id',id);if(error)toast(error.message,false);else{toast(p.active?'Product hidden':'Product is now visible');await load();}};
window.del=async id=>{const p=products.find(x=>String(x.id)===String(id));if(!p)return;if(!confirm(`Delete “${p.name}”?`))return;const {error}=await sb.from('products').delete().eq('id',id);if(error)toast(error.message,false);else{toast('Product deleted');await load();}};

$('pimageurl').oninput=()=>{$('preview').src=$('pimageurl').value.trim()||'../assets/sadee-solutions.jpg';};
$('pimage').onchange=()=>{const f=$('pimage').files[0];if(f)$('preview').src=URL.createObjectURL(f);};
$('save').onclick=async()=>{
  const id=$('pid').value,name=$('pname').value.trim();
  if(!name){$('saveMsg').textContent='Product name is required.';return;}
  $('save').disabled=true;$('save').textContent='SAVING…';$('saveMsg').textContent='';
  try{
    let image=$('pimageurl').value.trim(),file=$('pimage').files[0];
    if(file){const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,'_'),path=`${crypto.randomUUID()}-${safe}`;const up=await sb.storage.from('product-media').upload(path,file,{upsert:false,contentType:file.type});if(up.error)throw new Error(up.error.message);image=sb.storage.from('product-media').getPublicUrl(path).data.publicUrl;}
    const row={name,category:$('pcat').value.trim()||'Digital Product',price:Number($('pprice').value||0),price_note:$('pnote').value.trim(),description:$('pdesc').value.trim(),features:$('pfeatures').value.split('\n').map(x=>x.trim()).filter(Boolean),image_url:image,featured:$('pfeatured').checked,active:$('pactive').checked,updated_at:new Date().toISOString()};
    const r=id?await sb.from('products').update(row).eq('id',id):await sb.from('products').insert(row);
    if(r.error)throw new Error(r.error.message);
    $('modal').classList.remove('show');toast(id?'Product updated':'Product added');await load();
  }catch(e){$('saveMsg').textContent=e.message;toast(e.message,false);}finally{$('save').disabled=false;$('save').textContent='SAVE PRODUCT';}
};

$('newBtn').onclick=()=>openForm();$('close').onclick=()=>$('modal').classList.remove('show');$('modal').addEventListener('click',e=>{if(e.target.id==='modal')$('close').click();});$('refreshBtn').onclick=load;$('adminSearch').oninput=render;$('adminFilter').onchange=render;
document.querySelectorAll('.side').forEach(b=>b.onclick=()=>{document.querySelectorAll('.side').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById(b.dataset.section).scrollIntoView({behavior:'smooth',block:'start'});});
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('modal').classList.remove('show');});
start();
